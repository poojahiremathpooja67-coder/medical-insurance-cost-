# Medical Insurance Cost Prediction

## Synopsis
This project focuses on predicting medical insurance costs based on information such as age, gender, BMI, number of children, smoking status, and region. Students analyze which factors have the biggest effect on insurance costs and build a regression model to estimate the cost.

## Objectives
- Analyze insurance customer data.
- Identify factors affecting insurance costs.
- Visualize relationships between features.
- Train a regression model.
- Predict insurance costs.
- Evaluate the model.

## Tools
Python, Pandas, Matplotlib, Scikit-learn

## Dataset Features
- customer_id
- age
- gender
- bmi
- children
- smoker
- region
- insurance_cost

Target:
- insurance_cost — predicted medical insurance cost

## Data Preparation
- Loaded the insurance dataset using Pandas.
- Checked for missing values.
- Filled missing numerical values with median values.
- Filled missing categorical values with the most frequent value.
- Standardized numerical features.
- One-hot encoded categorical features.
- Split the dataset into training and testing sets.

## Machine Learning Algorithm
Linear Regression is used as the regression model.

## Evaluation
The program calculates:
- Mean Absolute Error (MAE)
- Root Mean Squared Error (RMSE)
- R² Score
- Actual vs predicted insurance-cost comparison
- Predicted insurance cost for a new customer
- Important factors based on regression coefficients

It also generates:
- `age_vs_insurance_cost.png`
- `bmi_vs_insurance_cost.png`
- `smoker_vs_insurance_cost.png`
- `actual_vs_predicted.png`

## How to Run
1. Install Python.
2. Open a terminal in this project folder.
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python medical_insurance_cost_prediction.py

## Dataset Note
The included medical-insurance dataset is synthetic and intended for educational/classroom machine-learning practice. It does not contain real customer or medical records.

## Important Note
This project is for educational purposes. Model predictions should not be used as the sole basis for real-world insurance, healthcare, or financial decisions.
