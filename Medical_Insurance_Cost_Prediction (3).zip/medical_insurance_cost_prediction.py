# Medical Insurance Cost Prediction
# Tools: Python, Pandas, Matplotlib, Scikit-learn

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Load dataset
data = pd.read_csv("medical_insurance.csv")

print("First 5 rows:")
print(data.head())

print("\nDataset shape:", data.shape)

print("\nMissing values before cleaning:")
print(data.isnull().sum())

# Features and target
X = data.drop(columns=["customer_id", "insurance_cost"])
y = data["insurance_cost"]

numeric_features = ["age", "bmi", "children"]
categorical_features = ["gender", "smoker", "region"]

# Preprocessing
numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])

categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer([
    ("num", numeric_pipeline, numeric_features),
    ("cat", categorical_pipeline, categorical_features)
])

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Regression model
model = Pipeline([
    ("preprocessor", preprocessor),
    ("regressor", LinearRegression())
])

# Train model
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Evaluation
mae = mean_absolute_error(y_test, y_pred)
rmse = mean_squared_error(y_test, y_pred) ** 0.5
r2 = r2_score(y_test, y_pred)

print(f"\nMean Absolute Error (MAE): {mae:.2f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")
print(f"R² Score: {r2:.4f}")

# Actual vs predicted comparison
comparison = pd.DataFrame({
    "Actual Insurance Cost": y_test.values,
    "Predicted Insurance Cost": y_pred.round(2)
})

print("\nActual vs Predicted Insurance Costs:")
print(comparison.head(10))

# Predict insurance cost for a new customer
new_customer = pd.DataFrame([{
    "age": 35,
    "gender": "Female",
    "bmi": 28.5,
    "children": 2,
    "smoker": "No",
    "region": "Southwest"
}])

predicted_cost = model.predict(new_customer)[0]
print(f"\nPredicted Medical Insurance Cost: {predicted_cost:.2f}")

# Analyze feature impact using regression coefficients
feature_names = model.named_steps["preprocessor"].get_feature_names_out()
coefficients = model.named_steps["regressor"].coef_

importance = pd.DataFrame({
    "feature": feature_names,
    "coefficient": coefficients,
    "absolute_impact": abs(coefficients)
}).sort_values("absolute_impact", ascending=False)

print("\nTop Factors Affecting Insurance Cost:")
print(importance.head(12)[["feature", "coefficient"]])

# Visualization 1: age vs insurance cost
plt.figure(figsize=(8, 5))
plt.scatter(data["age"], data["insurance_cost"], alpha=0.6)
plt.xlabel("Age")
plt.ylabel("Insurance Cost")
plt.title("Age vs Medical Insurance Cost")
plt.tight_layout()
plt.savefig("age_vs_insurance_cost.png", dpi=150)
plt.show()

# Visualization 2: BMI vs insurance cost
plt.figure(figsize=(8, 5))
plt.scatter(data["bmi"], data["insurance_cost"], alpha=0.6)
plt.xlabel("BMI")
plt.ylabel("Insurance Cost")
plt.title("BMI vs Medical Insurance Cost")
plt.tight_layout()
plt.savefig("bmi_vs_insurance_cost.png", dpi=150)
plt.show()

# Visualization 3: smoker status and average cost
smoker_cost = data.groupby("smoker", dropna=False)["insurance_cost"].mean()

plt.figure(figsize=(8, 5))
smoker_cost.plot(kind="bar")
plt.xlabel("Smoking Status")
plt.ylabel("Average Insurance Cost")
plt.title("Average Insurance Cost by Smoking Status")
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("smoker_vs_insurance_cost.png", dpi=150)
plt.show()

# Visualization 4: actual vs predicted
plt.figure(figsize=(8, 5))
plt.scatter(y_test, y_pred, alpha=0.6)
plt.xlabel("Actual Insurance Cost")
plt.ylabel("Predicted Insurance Cost")
plt.title("Actual vs Predicted Insurance Costs")
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)
plt.show()
